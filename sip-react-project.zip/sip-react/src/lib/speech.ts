// ===== SPEECH SYNTHESIS =====
export function speak(text: string, onEnd?: () => void): void {
  if (!window.speechSynthesis) return
  window.speechSynthesis.cancel()
  const u = new SpeechSynthesisUtterance(text)
  u.lang = 'id-ID'
  u.rate = 0.95
  u.pitch = 1.1
  u.volume = 1
  if (onEnd) {
    u.onend = onEnd
    u.onerror = onEnd
  }
  // slight delay to ensure cancel is processed
  setTimeout(() => window.speechSynthesis.speak(u), 120)
}

export function stopSpeaking(): void {
  if (window.speechSynthesis) window.speechSynthesis.cancel()
}

// ===== SPEECH RECOGNITION =====
export type RecognitionCallback = (transcript: string) => void
export type RecognitionInterimCallback = (interim: string) => void

export interface SpeechRecognitionHandle {
  stop: () => void
}

export function startRecognition(
  onResult: RecognitionCallback,
  onInterim?: RecognitionInterimCallback,
  onError?: (msg: string) => void
): SpeechRecognitionHandle | null {
  const SR =
    (window as unknown as { SpeechRecognition?: typeof SpeechRecognition; webkitSpeechRecognition?: typeof SpeechRecognition })
      .SpeechRecognition ||
    (window as unknown as { webkitSpeechRecognition?: typeof SpeechRecognition }).webkitSpeechRecognition

  if (!SR) {
    onError?.('Browser tidak mendukung pengenalan suara.')
    return null
  }

  const r = new SR()
  r.lang = 'id-ID'
  r.continuous = false
  r.interimResults = true
  r.maxAlternatives = 5

  r.onresult = (e: SpeechRecognitionEvent) => {
    let interim = ''
    let final = ''
    for (let i = e.resultIndex; i < e.results.length; i++) {
      if (e.results[i].isFinal) final += e.results[i][0].transcript
      else interim += e.results[i][0].transcript
    }
    if (interim) onInterim?.(interim)
    if (final) { r.stop(); onResult(final.trim()) }
  }

  r.onerror = (e: SpeechRecognitionErrorEvent) => {
    onError?.(e.error)
  }

  try { r.start() } catch (_e) { onError?.('Gagal memulai mikrofon') }

  return { stop: () => { try { r.stop() } catch (_e) { /* ignore */ } } }
}

export async function requestMicPermission(): Promise<boolean> {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
    stream.getTracks().forEach(t => t.stop())
    return true
  } catch {
    return false
  }
}
