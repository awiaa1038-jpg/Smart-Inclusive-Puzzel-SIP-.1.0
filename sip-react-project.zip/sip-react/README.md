# 🧩 Smart Inclusive Puzzle (SIP)

AI-powered interactive math puzzle untuk siswa SD, dengan sistem suara penuh, deteksi suara, dan 16 kepingan puzzle interaktif.

## ✨ Fitur Lengkap

| Fitur | Keterangan |
|-------|-----------|
| 🤖 AI Voice Full | AI berbicara membacakan soal, instruksi, sapaan, notif benar/salah |
| 🎤 Speech Recognition | Jawab soal cukup dengan berbicara |
| 🧩 16 Kepingan Puzzle | Setiap keping punya soal matematika SD berbeda |
| 🎲 Urutan Acak | AI memanggil kepingan secara acak (bukan 1-2-3-4) |
| 🖼️ Foto SIP Nyata | Foto puzzle tersusun di papan saat menjawab benar |
| 📱 Fully Responsive | HP, tablet, laptop, komputer semua support |
| 🏆 6 Soal Bonus | Muncul otomatis setelah puzzle sempurna |
| 🎉 Konfeti & Animasi | Efek visual keren saat berhasil |
| 🔒 Izin Mic Sekali | Hanya minta izin mic sekali selama di halaman ini |

## 🚀 Deploy ke Vercel via GitHub

### Step 1 — Buat Repository GitHub
```bash
git init
git add .
git commit -m "🧩 Smart Inclusive Puzzle (SIP) - Initial"
git branch -M main
git remote add origin https://github.com/USERNAME/smart-inclusive-puzzle.git
git push -u origin main
```

### Step 2 — Deploy ke Vercel
1. Buka [vercel.com](https://vercel.com) → Login / Daftar
2. Klik **"Add New Project"**
3. Import repo GitHub kamu
4. Settings:
   - **Framework Preset**: Vite
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
5. Klik **"Deploy"** ✅

Vercel otomatis build dan deploy! URL seperti: `https://smart-inclusive-puzzle.vercel.app`

### Step 3 — Development Lokal
```bash
npm install
npm run dev
# Buka http://localhost:5173
```

## 📋 Soal Puzzle (16 Kepingan — Urutan Acak)

| # | Soal | Jawaban |
|---|------|---------|
| 1 | 7 + 5 apel | **12** |
| 2 | 20 − 8 telur | **12** |
| 3 | 4 × 6 pensil | **24** |
| 4 | 8 − 3 pizza | **5** |
| 5 | 9 × 5 kelopak | **45** |
| 6 | 6 × 4 kursi | **24** |
| 7 | 15 − 6 bola | **9** |
| 8 | 30 ÷ 5 permen | **6** |
| 9 | 7 × 8 buku | **56** |
| 10 | 40 − 13 ikan | **27** |
| 11 | 48 ÷ 6 balon | **8** |
| 12 | 18 + 15 siswa | **33** |
| 13 | 9 × 4 peserta | **36** |
| 14 | 63 − 25 bunga | **38** |
| 15 | 3 × 7 menit | **21** |
| 16 | 72 ÷ 8 lampu | **9** |

## 🏆 6 Soal Bonus (Setelah Puzzle Selesai)

1. 12 + 8 siswa = **20**
2. 25 − 9 permen = **16**
3. 6 × 15 buku = **90**
4. 4 × 12 jeruk = **48**
5. 240 ÷ 30 kelas = **8**
6. 50 − 18 − 7 uang = **25**

## 🛠️ Stack Teknologi

- **React 19** + TypeScript
- **Vite 7** (build tool)
- **Tailwind CSS 3** + tailwindcss-animate
- **Radix UI** (Dialog, Progress)
- **Web Speech API** (SpeechSynthesis + SpeechRecognition)
- **Lucide React** (icons)

## 📱 Browser Support

| Browser | Voice Synthesis | Speech Recognition |
|---------|:--------------:|:-----------------:|
| Chrome | ✅ | ✅ |
| Edge | ✅ | ✅ |
| Safari iOS 14+ | ✅ | ⚠️ Terbatas |
| Firefox | ✅ | ❌ |
| Samsung Internet | ✅ | ✅ |

**Rekomendasi**: Gunakan **Chrome** atau **Edge** untuk pengalaman terbaik dengan deteksi suara.
