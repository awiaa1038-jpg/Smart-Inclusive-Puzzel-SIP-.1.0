import { cn } from '@/lib/utils'
import { useApp } from '@/context/AppContext'

const PUZZLE_IMAGE = '/puzzle-image.jpg'

export default function PuzzleBoard() {
  const { answeredPieces } = useApp()

  return (
    <div className="bg-white/[0.07] backdrop-blur-xl border border-white/15 rounded-2xl p-4 shadow-xl">
      <h3 className="text-center font-extrabold text-emerald-300 mb-3 text-sm flex items-center justify-center gap-2">
        🖼️ Papan Puzzle
      </h3>

      {/* Board: aspect ratio matches 2000x1414 ≈ 1.414 */}
      <div
        className="grid grid-cols-4 gap-[3px] rounded-xl overflow-hidden border-2 border-emerald-400/30"
        style={{ aspectRatio: '2000/1414' }}
      >
        {Array.from({ length: 16 }, (_, i) => {
          const id = i + 1
          const filled = answeredPieces.has(id)
          const col = i % 4
          const row = Math.floor(i / 4)
          // 4 cols, 4 rows → each piece is 25% × 25%
          const bgX = (col / 3) * 100
          const bgY = (row / 3) * 100

          return (
            <div
              key={id}
              className={cn(
                "relative overflow-hidden bg-white/5 border border-white/[0.07] transition-all duration-300",
                filled && "border-emerald-400/40"
              )}
            >
              {/* Puzzle image slice */}
              <div
                className={cn(
                  "absolute inset-0 transition-opacity duration-500",
                  filled ? "opacity-100" : "opacity-0"
                )}
                style={{
                  backgroundImage: `url(${PUZZLE_IMAGE})`,
                  backgroundSize: '400% 400%',
                  backgroundPosition: `${bgX}% ${bgY}%`,
                }}
              />
              {/* Cell number when empty */}
              {!filled && (
                <div className="absolute inset-0 flex items-center justify-center text-violet-400/30 font-black text-xs select-none">
                  {id}
                </div>
              )}
              {/* Place animation flash */}
              {filled && (
                <div className="absolute inset-0 border-2 border-emerald-400 rounded-[1px] opacity-0 animate-[fadeOut_1.5s_ease_forwards]" />
              )}
            </div>
          )
        })}
      </div>

      <p className="text-center text-white/30 text-xs mt-2 font-semibold">
        {answeredPieces.size} / 16 kepingan terpasang
      </p>
    </div>
  )
}
