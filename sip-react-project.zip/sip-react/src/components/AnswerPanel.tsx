import { useState, useRef, useEffect } from 'react'
import { useApp } from '@/context/AppContext'
import { Button } from '@/components/ui/button'
import { parseSpokenNumber, PUZZLE_PIECES } from '@/lib/data'
import { cn } from '@/lib/utils'

interface AnswerPanelProps {
  activePieceId: number | null
  onCorrect: (id: number) => void
  onHide: () => void
}

type FeedbackState = 'idle' | 'correct' | 'wrong'

export default function AnswerPanel({ activePieceId, onCorrect, onHide }: AnswerPanelProps) {
  const { aiSpeak, micAllowed, startListening, stopListening, isListening } = useApp()
  const [inputVal, setInputVal] = useState('')
  const [feedback, setFeedback] = useState<FeedbackState>('idle')
  const [feedbackMsg, setFeedbackMsg] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)

  const piece = activePieceId ? PUZZLE_PIECES.find(p => p.id === activePieceId) : null

  useEffect(() => {
    if (piece) {
      setInputVal('')
      setFeedback('idle')
      setFeedbackMsg('')
      setTimeout(() => inputRef.current?.focus(), 100)
    }
  }, [piece])

  const check = (raw: string | number) => {
    if (!piece) return
    const val = typeof raw === 'number' ? raw : parseInt(String(raw))
    if (isNaN(val)) { aiSpeak('Masukkan jawaban dulu ya!'); return }

    if (val === piece.answer) {
      setFeedback('correct')
      setFeedbackMsg(`✅ Benar! Jawaban ${piece.answer} tepat sekali! Kepingan puzzle dipasang! 🎉`)
      aiSpeak(`Benar! Jawaban ${piece.answer} tepat sekali! Kepingan nomor ${piece.id} berhasil dipasang!`, () => {
        setTimeout(() => {
          onCorrect(piece.id)
          onHide()
        }, 300)
      })
    } else {
      setFeedback('wrong')
      setFeedbackMsg(`❌ Jawaban kamu ${val} belum tepat. Petunjuk: ${piece.hint}`)
      aiSpeak(`Jawaban kamu ${val} belum tepat. Coba lagi ya! Petunjuk: ${piece.hint}`)
      setInputVal('')
      setTimeout(() => inputRef.current?.focus(), 200)
    }
  }

  const handleVoiceListen = () => {
    if (isListening) { stopListening(); return }
    startListening((text) => {
      const n = parseSpokenNumber(text)
      if (n !== null) {
        setInputVal(String(n))
        check(n)
      } else {
        aiSpeak('Jawaban tidak terdeteksi, coba lagi ya!')
      }
    }, `Sebutkan jawaban untuk soal nomor ${piece?.id}...`)
  }

  if (!piece) return null

  return (
    <div className="bg-white/[0.07] backdrop-blur-xl border border-white/15 rounded-2xl p-5 mt-4 shadow-xl animate-fade-up">
      {/* Question */}
      <div className="bg-violet-500/10 border border-violet-400/25 rounded-xl p-4 mb-4 text-center">
        <span className="text-white/90 font-bold text-sm md:text-base leading-relaxed">
          🧮 {piece.question}
        </span>
      </div>

      {/* Input row */}
      <div className="flex flex-wrap gap-2 justify-center items-center mb-3">
        <input
          ref={inputRef}
          type="number"
          inputMode="numeric"
          value={inputVal}
          onChange={e => setInputVal(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && inputVal && check(inputVal)}
          placeholder="Ketik jawaban..."
          className={cn(
            "flex-1 min-w-[140px] max-w-[200px] px-5 py-3 rounded-full border-2 bg-white/8 text-white font-bold text-center text-base",
            "placeholder:text-white/30 outline-none transition-all",
            feedback === 'correct' ? "border-emerald-400" :
            feedback === 'wrong' ? "border-red-400" :
            "border-violet-400/40 focus:border-violet-400"
          )}
        />
        {micAllowed && (
          <Button
            size="icon"
            variant={isListening ? 'listening' : 'green'}
            onClick={handleVoiceListen}
            title="Jawab dengan suara"
          >
            🎤
          </Button>
        )}
        <Button
          variant="default"
          onClick={() => inputVal && check(inputVal)}
          disabled={!inputVal}
        >
          ✅ Jawab
        </Button>
        <Button variant="ghost" size="sm" onClick={onHide} className="text-white/40 hover:text-white/70">
          ✕
        </Button>
      </div>

      {/* Feedback */}
      {feedback !== 'idle' && (
        <div className={cn(
          "text-center rounded-xl px-4 py-3 font-bold text-sm animate-fade-up",
          feedback === 'correct'
            ? "bg-emerald-400/12 text-emerald-300 border border-emerald-400/30"
            : "bg-red-400/10 text-red-300 border border-red-400/25"
        )}>
          {feedbackMsg}
        </div>
      )}
    </div>
  )
}
