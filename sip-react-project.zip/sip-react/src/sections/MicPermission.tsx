import { useApp } from '@/context/AppContext'
import { Button } from '@/components/ui/button'

export default function MicPermission() {
  const { initMic, skipMic } = useApp()

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/70 backdrop-blur-md px-5">
      <div className="relative w-full max-w-md bg-gradient-to-br from-[#1a0533] via-[#0b1e3d] to-[#0d3320] border border-white/15 rounded-3xl p-8 text-center shadow-2xl animate-bounce-in">
        {/* Glow orb */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-28 h-28 rounded-full bg-violet-500/20 blur-2xl" />

        <div className="text-6xl mb-4 animate-mic-bounce">🎤</div>
        <h2 className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-violet-300 to-sky-300 mb-3">
          Aktifkan Mikrofon Yuk!
        </h2>
        <p className="text-white/60 text-sm leading-relaxed mb-8">
          Smart Inclusive Puzzle menggunakan{' '}
          <span className="text-violet-300 font-bold">deteksi suara</span> untuk interaksi penuh!
          Izinkan akses mikrofon agar kamu bisa menjawab soal dengan berbicara langsung.
          <br />
          <span className="text-emerald-400 font-semibold mt-2 block">
            ✅ Izin hanya diminta sekali selama di halaman ini.
          </span>
        </p>

        <div className="flex flex-col gap-3">
          <Button size="lg" onClick={initMic} className="w-full text-base">
            🎤 Izinkan Mikrofon
          </Button>
          <Button size="default" variant="outline" onClick={skipMic} className="w-full">
            Lewati — Gunakan Teks Saja
          </Button>
        </div>

        <p className="text-white/30 text-xs mt-4">
          Rekomendasi: Gunakan Chrome atau Edge untuk pengalaman terbaik
        </p>
      </div>
    </div>
  )
}
