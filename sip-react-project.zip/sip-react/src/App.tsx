import { AppProvider, useApp } from '@/context/AppContext'
import SplashScreen from '@/sections/SplashScreen'
import MicPermission from '@/sections/MicPermission'
import GameScreen from '@/sections/GameScreen'

function AppContent() {
  const { view } = useApp()

  if (view === 'splash') return <SplashScreen />
  if (view === 'mic') return (
    <>
      <GameScreen />
      <MicPermission />
    </>
  )
  return <GameScreen />
}

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  )
}

export default App
