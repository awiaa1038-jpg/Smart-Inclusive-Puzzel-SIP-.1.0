import { useState, useEffect } from 'react'
import { useApp } from '@/context/AppContext'
import { Button } from '@/components/ui/button'
import { FINAL_QUESTIONS, parseSpokenNumber } from '@/lib/data'
import { cn } from '@/lib/utils'

interface FinalModalProps {
  open: boolean
  onReset: () => void
}

type QState = 'idle' | 'correct' | 'wrong'

export default function FinalModal({ open, onReset }: FinalModalProps) {
  const { aiSpeak, micAllowed, startListening, stopListening, isListening,
          finalAnswered, addFinalAnswered, finalScore, addFinalScore } = useApp()
  const [inputs, setInputs] = useState<string[]>(Array(6).fill(''))
  const [states, setStates] = useState<QState[]>(Array(6).fill('idle'))
  const [messages, setMessages] = useState<string[]>(Array(6).fill(''))
  const [activeVoiceIdx, setActiveVoiceIdx] = useState<number | null>(null)
  const [allDone, setAllDone] = useState(false)

  useEffect(() => {
    if (open) {
      setInputs(Array(6).fill(''))
      setStates(Array(6).fill('idle'))
      setMessages(Array(6).fill(''))
      setAllDone(false)
      setTimeout(() => {
        aiSpeak('Luar biasa! Kamu berhasil menyusun semua kepingan puzzle! Sekarang ada 6 soal bonus yang menunggumu! Yuk jawab soal pertama!')
      }, 400)
    }
  }, [open, aiSpeak])

  const check = (idx: number, raw: string | number) => {
    if (finalAnswered.has(idx)) return
    const val = typeof raw === 'number' ? raw : parseInt(String(raw))
    const fq = FINAL_QUESTIONS[idx]
    if (isNaN(val)) { aiSpeak('Masukkan jawaban dulu ya!'); return }

    const newStates = [...states]
    const newMessages = [...messages]

    if (val === fq.answer) {
      newStates[idx] = 'correct'
      newMessages[idx] = `✅ Benar! Jawabannya ${fq.answer}. Keren sekali!`
      setStates(newStates)
      setMessages(newMessages)
      addFinalAnswered(idx)
      addFinalScore()

      const nextUnanswered = FINAL_QUESTIONS.findIndex((_, i) => i > idx && !finalAnswered.has(i) && newStates[i] !== 'correct')
      
      aiSpeak(`Benar! Jawaban soal ${idx + 1} adalah ${fq.answer}. Kamu pintar!`, () => {
        if (nextUnanswered !== -1) {
          aiSpeak(`Lanjut soal nomor ${nextUnanswered + 1}: ${FINAL_QUESTIONS[nextUnanswered].question}`)
        } else {
          // check truly all done
          const answeredCount = newStates.filter(s => s === 'correct').length
          if (answeredCount === 6) {
            setAllDone(true)
            launchConfetti()
            aiSpeak(`Selesai! Kamu menjawab ${answeredCount} dari 6 soal. Luar biasa! Terima kasih sudah bermain Smart Inclusive Puzzle!`)
          }
        }
      })
    } else {
      newStates[idx] = 'wrong'
      newMessages[idx] = `❌ Jawaban ${val} belum tepat. Coba lagi!`
      setStates(newStates)
      setMessages(newMessages)
      setInputs(prev => { const n=[...prev]; n[idx]=''; return n })
      aiSpeak(`Jawaban kamu ${val} belum tepat untuk soal ${idx + 1}. Coba lagi ya!`, () => {
        newStates[idx] = 'idle'
        newMessages[idx] = ''
        setStates([...newStates])
        setMessages([...newMessages])
      })
    }
  }

  const handleVoice = (idx: number) => {
    if (isListening && activeVoiceIdx === idx) { stopListening(); setActiveVoiceIdx(null); return }
    setActiveVoiceIdx(idx)
    startListening((text) => {
      setActiveVoiceIdx(null)
      const n = parseSpokenNumber(text)
      if (n !== null) {
        setInputs(prev => { const a=[...prev]; a[idx]=String(n); return a })
        check(idx, n)
      } else {
        aiSpeak('Jawaban tidak terdeteksi, coba lagi ya!')
      }
    }, `Jawab soal ${idx + 1}...`)
  }

  const launchConfetti = () => {
    const colors = ['#a78bfa','#38bdf8','#4ade80','#fbbf24','#f472b6','#fb923c']
    for (let i = 0; i < 60; i++) {
      setTimeout(() => {
        const el = document.createElement('div')
        el.className = 'conf'
        const s = Math.random() * 12 + 6
        el.style.cssText = `position:fixed;pointer-events:none;z-index:9999;top:-10px;border-radius:${Math.random()>0.5?'50%':'3px'};width:${s}px;height:${s*0.6}px;left:${Math.random()*100}vw;background:${colors[Math.floor(Math.random()*colors.length)]};animation:conf-fall ${Math.random()*2+2}s ${Math.random()*0.5}s linear forwards;`
        document.body.appendChild(el)
        setTimeout(() => el.remove(), 4000)
      }, i * 45)
    }
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 z-[600] flex items-start justify-center bg-black/80 backdrop-blur-md overflow-y-auto py-6 px-4">
      <div className="w-full max-w-2xl bg-gradient-to-br from-[#1a0533] via-[#0b1e3d] to-[#0d3320] border-2 border-violet-400/40 rounded-3xl p-6 shadow-2xl my-auto animate-bounce-in">
        {/* Header */}
        <div className="text-center mb-5">
          <div className="text-5xl mb-2">🎉</div>
          <h2 className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-violet-300 via-sky-300 to-emerald-300">
            Puzzle Selesai! Hebat!
          </h2>
          <p className="text-white/50 text-sm mt-1">
            Kamu berhasil menyusun puzzle! Sekarang jawab 6 soal bonus ini ya!
          </p>
        </div>

        {/* Questions */}
        <div className="space-y-3">
          {FINAL_QUESTIONS.map((fq, idx) => {
            const answered = finalAnswered.has(idx) || states[idx] === 'correct'
            const isVoiceActive = isListening && activeVoiceIdx === idx

            return (
              <div
                key={fq.id}
                className={cn(
                  "rounded-2xl p-4 border transition-all duration-300",
                  answered
                    ? "border-emerald-400/40 bg-emerald-400/[0.06]"
                    : states[idx] === 'wrong'
                    ? "border-red-400/40 bg-red-400/[0.06]"
                    : "border-white/10 bg-white/[0.04]"
                )}
              >
                <div className="flex items-start gap-3 mb-3">
                  <span className="w-7 h-7 rounded-full bg-gradient-to-br from-violet-500 to-sky-400 text-white text-xs font-black flex items-center justify-center shrink-0">
                    {idx + 1}
                  </span>
                  <p className="text-white/85 font-semibold text-sm leading-relaxed flex-1">
                    {fq.question}
                  </p>
                </div>

                {!answered && (
                  <div className="flex flex-wrap gap-2 items-center">
                    <input
                      type="number"
                      inputMode="numeric"
                      value={inputs[idx]}
                      onChange={e => setInputs(prev => { const a=[...prev]; a[idx]=e.target.value; return a })}
                      onKeyDown={e => e.key === 'Enter' && inputs[idx] && check(idx, inputs[idx])}
                      placeholder="Jawaban..."
                      className="flex-1 min-w-[110px] max-w-[160px] px-4 py-2.5 rounded-full border-2 border-violet-400/30 bg-white/8 text-white font-bold text-center text-sm placeholder:text-white/25 outline-none focus:border-violet-400 transition-all"
                    />
                    {micAllowed && (
                      <Button
                        size="icon"
                        variant={isVoiceActive ? 'listening' : 'green'}
                        onClick={() => handleVoice(idx)}
                        className="w-9 h-9 text-sm"
                      >
                        🎤
                      </Button>
                    )}
                    <Button
                      size="sm"
                      onClick={() => inputs[idx] && check(idx, inputs[idx])}
                      disabled={!inputs[idx]}
                    >
                      ✅
                    </Button>
                  </div>
                )}

                {messages[idx] && (
                  <p className={cn(
                    "text-xs font-bold mt-2",
                    states[idx] === 'correct' ? "text-emerald-400" : "text-red-400"
                  )}>
                    {messages[idx]}
                  </p>
                )}
              </div>
            )
          })}
        </div>

        {/* Score */}
        <div className="mt-5 text-center bg-white/[0.05] border border-white/10 rounded-2xl p-4">
          <p className="text-white/50 text-xs font-bold uppercase tracking-widest mb-1">Skor Soal Bonus</p>
          <p className="text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-300 to-orange-300">
            {finalScore} / 6
          </p>
          {allDone && (
            <p className="text-emerald-400 font-bold text-sm mt-1">
              {finalScore === 6 ? '🌟 Sempurna! Semua benar!' : `🎯 ${finalScore} dari 6 benar. Keren!`}
            </p>
          )}
        </div>

        <Button size="lg" className="w-full mt-4" onClick={onReset}>
          🔄 Mulai Ulang
        </Button>
      </div>
    </div>
  )
}
