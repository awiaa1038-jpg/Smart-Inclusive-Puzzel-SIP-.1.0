import { useEffect, useState, useCallback } from 'react'
import { useApp } from '@/context/AppContext'
import { PUZZLE_PIECES, shuffleArray } from '@/lib/data'
import { Progress } from '@/components/ui/progress'
import AIPanel from '@/components/AIPanel'
import PieceBank from '@/components/PieceBank'
import PuzzleBoard from '@/components/PuzzleBoard'
import AnswerPanel from '@/components/AnswerPanel'
import ListenOverlay from '@/components/ListenOverlay'
import FinalModal from '@/components/FinalModal'

export default function GameScreen() {
  const {
    aiSpeak, answeredPieces, markPieceAnswered, resetAnsweredPieces,
    currentOrderRef, currentOrderIndexRef,
    activePieceId, setActivePieceId,
    resetFinalState,
  } = useApp()

  const [currentAIpieceId, setCurrentAIPieceId] = useState<number | null>(null)
  const [showFinal, setShowFinal] = useState(false)

  // Advance to next piece in random order
  const advanceToNext = useCallback(() => {
    const order = currentOrderRef.current
    let idx = currentOrderIndexRef.current
    // skip already answered
    while (idx < order.length && answeredPieces.has(order[idx])) idx++
    currentOrderIndexRef.current = idx

    if (idx >= order.length) return

    const nextId = order[idx]
    currentOrderIndexRef.current = idx + 1
    const piece = PUZZLE_PIECES.find(p => p.id === nextId)!

    setCurrentAIPieceId(nextId)
    setTimeout(() => {
      aiSpeak(
        `Selanjutnya, kepingan nomor ${nextId}! ${piece.question} Jawab ya!`,
        () => {
          setActivePieceId(nextId)
        }
      )
    }, 350)
    // scroll to that card
    setTimeout(() => {
      document.getElementById(`piece-card-${nextId}`)?.scrollIntoView({ behavior: 'smooth', block: 'nearest' })
    }, 500)
  }, [aiSpeak, answeredPieces, currentOrderRef, currentOrderIndexRef, setActivePieceId])

  // Init game
  useEffect(() => {
    const randomOrder = shuffleArray(PUZZLE_PIECES.map(p => p.id))
    currentOrderRef.current = randomOrder
    currentOrderIndexRef.current = 0

    aiSpeak(
      'Halo teman-teman! Selamat datang di Smart Inclusive Puzzle! Aku akan membacakan soal untuk setiap kepingan. Jawab dengan benar untuk memasang kepingan ke papan puzzle! Yuk kita mulai!',
      () => setTimeout(advanceToNext, 400)
    )
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handleSelectPiece = (id: number) => {
    setActivePieceId(id)
    const piece = PUZZLE_PIECES.find(p => p.id === id)!
    aiSpeak(`Kepingan nomor ${id}! ${piece.question} Berapa jawabannya?`)
  }

  const handleCorrect = (id: number) => {
    markPieceAnswered(id)
    const newCount = answeredPieces.size + 1
    if (newCount >= 16) {
      setCurrentAIPieceId(null)
      setTimeout(() => setShowFinal(true), 800)
    } else {
      setTimeout(() => advanceToNext(), 600)
    }
  }

  const handleHideAnswer = () => {
    setActivePieceId(null)
  }

  const handleReset = () => {
    setShowFinal(false)
    resetAnsweredPieces()
    resetFinalState()
    setActivePieceId(null)
    setCurrentAIPieceId(null)
    const randomOrder = shuffleArray(PUZZLE_PIECES.map(p => p.id))
    currentOrderRef.current = randomOrder
    currentOrderIndexRef.current = 0
    setTimeout(() => {
      aiSpeak(
        'Mulai ulang! Yuk susun puzzle lagi dari awal! Semangat!',
        () => setTimeout(advanceToNext, 400)
      )
    }, 200)
  }

  const progress = (answeredPieces.size / 16) * 100

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-950 via-[#0b1e3d] to-[#0d3320] px-3 py-4 md:px-5">
      {/* Floating bg orbs */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute top-[-10%] left-[-5%] w-72 h-72 rounded-full bg-violet-600/10 blur-3xl" />
        <div className="absolute bottom-[-10%] right-[-5%] w-80 h-80 rounded-full bg-sky-600/10 blur-3xl" />
        <div className="absolute top-[40%] left-[60%] w-60 h-60 rounded-full bg-emerald-600/8 blur-3xl" />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-4">
          <h1
            className="font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-violet-300 via-sky-300 to-emerald-300"
            style={{ fontSize: 'clamp(1.5rem,4vw,2.8rem)' }}
          >
            🧩 Smart Inclusive Puzzle (SIP)
          </h1>
          <p className="text-white/40 text-xs mt-1 font-semibold">Susun puzzle & jawab soal dengan suara!</p>
        </div>

        {/* AI Panel */}
        <AIPanel />

        {/* Progress */}
        <div className="mb-4">
          <div className="flex justify-between items-center mb-1.5">
            <span className="text-violet-300 font-black text-xs uppercase tracking-wide">⚡ Progress Puzzle</span>
            <span className="text-white/40 text-xs font-bold">{answeredPieces.size} / 16 kepingan</span>
          </div>
          <Progress value={progress} />
        </div>

        {/* Main layout */}
        <div className="flex flex-col lg:flex-row gap-4 items-start">
          {/* Piece bank */}
          <PieceBank
            onSelectPiece={handleSelectPiece}
            activePieceId={activePieceId}
            currentPieceId={currentAIpieceId}
          />

          {/* Board */}
          <div className="w-full lg:w-[340px] lg:min-w-[300px] shrink-0">
            <PuzzleBoard />
          </div>
        </div>

        {/* Answer panel */}
        <AnswerPanel
          activePieceId={activePieceId}
          onCorrect={handleCorrect}
          onHide={handleHideAnswer}
        />
      </div>

      {/* Listen overlay */}
      <ListenOverlay />

      {/* Final modal */}
      <FinalModal open={showFinal} onReset={handleReset} />
    </div>
  )
}
