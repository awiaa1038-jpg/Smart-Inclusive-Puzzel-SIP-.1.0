export interface PuzzlePiece {
  id: number
  emoji: string
  question: string
  answer: number
  hint: string
}

export interface FinalQuestion {
  id: number
  question: string
  answer: number
}

export type AppView = 'splash' | 'mic' | 'game' | 'complete'

export interface GameState {
  answeredPieces: Set<number>
  currentOrder: number[]
  currentOrderIndex: number
  activePieceId: number | null
  finalAnswered: Set<number>
  finalScore: number
}
