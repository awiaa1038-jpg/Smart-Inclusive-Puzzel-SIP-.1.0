import { useEffect } from 'react'
import { useApp } from '@/context/AppContext'

export default function SplashScreen() {
  const { setView } = useApp()

  useEffect(() => {
    const timer = setTimeout(() => setView('mic'), 2800)
    return () => clearTimeout(timer)
  }, [setView])

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-br from-violet-950 via-[#0b1e3d] to-[#0d3320] px-6">
      {/* Floating particles */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        {Array.from({ length: 14 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-violet-400/20"
            style={{
              width: `${Math.random() * 60 + 20}px`,
              height: `${Math.random() * 60 + 20}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float ${Math.random() * 6 + 5}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 4}s`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 flex flex-col items-center text-center">
        <div className="text-7xl md:text-8xl mb-4 animate-splash-float drop-shadow-2xl select-none">🧩</div>

        <h1
          className="font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-violet-300 via-sky-300 to-emerald-300 mb-3"
          style={{ fontSize: 'clamp(2rem,7vw,4.5rem)', lineHeight: 1.1 }}
        >
          Smart Inclusive<br />Puzzle
        </h1>

        <p className="text-white/60 text-lg mb-10 max-w-sm">
          Belajar Matematika Seru dengan AI Voice
        </p>

        <div className="flex items-center gap-3 bg-white/8 border border-violet-400/40 rounded-full px-7 py-4 shadow-xl">
          <span className="w-3 h-3 rounded-full bg-emerald-400 animate-blink-dot shadow-[0_0_8px_rgba(74,222,128,0.8)]" />
          <span className="text-white/80 font-semibold text-sm">AI sedang menyiapkan puzzle untukmu...</span>
        </div>
      </div>
    </div>
  )
}
