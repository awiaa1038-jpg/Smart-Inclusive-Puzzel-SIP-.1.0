import React, { createContext, useContext, useState, useCallback, useRef } from 'react'
import type { AppView } from '@/types'
import { speak, stopSpeaking, startRecognition, requestMicPermission } from '@/lib/speech'
import type { SpeechRecognitionHandle } from '@/lib/speech'

interface AppContextType {
  // View
  view: AppView
  setView: (v: AppView) => void
  // Mic
  micAllowed: boolean
  setMicAllowed: (v: boolean) => void
  initMic: () => Promise<void>
  skipMic: () => void
  // AI Speech
  aiMessage: string
  isSpeaking: boolean
  aiSpeak: (text: string, onEnd?: () => void) => void
  repeatLastAI: () => void
  // Voice listening
  isListening: boolean
  listenTranscript: string
  startListening: (onResult: (t: string) => void, hint?: string) => void
  stopListening: () => void
  // Game state
  answeredPieces: Set<number>
  markPieceAnswered: (id: number) => void
  resetAnsweredPieces: () => void
  currentOrderRef: React.MutableRefObject<number[]>
  currentOrderIndexRef: React.MutableRefObject<number>
  activePieceId: number | null
  setActivePieceId: (id: number | null) => void
  finalAnswered: Set<number>
  addFinalAnswered: (idx: number) => void
  finalScore: number
  addFinalScore: () => void
  resetFinalState: () => void
}

const AppContext = createContext<AppContextType | undefined>(undefined)

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [view, setView] = useState<AppView>('splash')
  const [micAllowed, setMicAllowed] = useState(false)
  const [aiMessage, setAiMessage] = useState('Selamat datang di Smart Inclusive Puzzle!')
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const [listenTranscript, setListenTranscript] = useState('')
  const [answeredPieces, setAnsweredPieces] = useState<Set<number>>(new Set())
  const [activePieceId, setActivePieceId] = useState<number | null>(null)
  const [finalAnswered, setFinalAnswered] = useState<Set<number>>(new Set())
  const [finalScore, setFinalScore] = useState(0)

  const lastAITextRef = useRef('')
  const recognitionHandleRef = useRef<SpeechRecognitionHandle | null>(null)
  const currentOrderRef = useRef<number[]>([])
  const currentOrderIndexRef = useRef(0)

  const aiSpeak = useCallback((text: string, onEnd?: () => void) => {
    lastAITextRef.current = text
    setAiMessage(text)
    setIsSpeaking(true)
    speak(text, () => {
      setIsSpeaking(false)
      onEnd?.()
    })
  }, [])

  const repeatLastAI = useCallback(() => {
    if (lastAITextRef.current) aiSpeak(lastAITextRef.current)
  }, [aiSpeak])

  const stopListeningFn = useCallback(() => {
    setIsListening(false)
    setListenTranscript('')
    recognitionHandleRef.current?.stop()
    recognitionHandleRef.current = null
  }, [])

  const startListeningFn = useCallback((onResult: (t: string) => void, hint?: string) => {
    if (!micAllowed) return
    if (isListening) stopListeningFn()
    setIsListening(true)
    setListenTranscript(hint || 'Menunggu suara kamu...')
    const handle = startRecognition(
      (transcript) => {
        setIsListening(false)
        setListenTranscript('')
        onResult(transcript)
      },
      (interim) => setListenTranscript(interim),
      (_err) => {
        setIsListening(false)
        setListenTranscript('')
      }
    )
    recognitionHandleRef.current = handle
  }, [micAllowed, isListening, stopListeningFn])

  const initMic = useCallback(async () => {
    const ok = await requestMicPermission()
    setMicAllowed(ok)
    setView('game')
  }, [])

  const skipMic = useCallback(() => {
    setMicAllowed(false)
    setView('game')
  }, [])

  const markPieceAnswered = useCallback((id: number) => {
    setAnsweredPieces(prev => new Set([...prev, id]))
  }, [])

  const resetAnsweredPieces = useCallback(() => {
    setAnsweredPieces(new Set())
    stopSpeaking()
  }, [])

  const addFinalAnswered = useCallback((idx: number) => {
    setFinalAnswered(prev => new Set([...prev, idx]))
  }, [])

  const addFinalScore = useCallback(() => {
    setFinalScore(prev => prev + 1)
  }, [])

  const resetFinalState = useCallback(() => {
    setFinalAnswered(new Set())
    setFinalScore(0)
  }, [])

  return (
    <AppContext.Provider value={{
      view, setView,
      micAllowed, setMicAllowed, initMic, skipMic,
      aiMessage, isSpeaking, aiSpeak, repeatLastAI,
      isListening, listenTranscript, startListening: startListeningFn, stopListening: stopListeningFn,
      answeredPieces, markPieceAnswered, resetAnsweredPieces,
      currentOrderRef, currentOrderIndexRef,
      activePieceId, setActivePieceId,
      finalAnswered, addFinalAnswered,
      finalScore, addFinalScore,
      resetFinalState,
    }}>
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}
