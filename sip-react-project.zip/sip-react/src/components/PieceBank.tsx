import { cn } from '@/lib/utils'
import { useApp } from '@/context/AppContext'
import { PUZZLE_PIECES } from '@/lib/data'

interface PieceBankProps {
  onSelectPiece: (id: number) => void
  activePieceId: number | null
  currentPieceId: number | null
}

export default function PieceBank({ onSelectPiece, activePieceId, currentPieceId }: PieceBankProps) {
  const { answeredPieces } = useApp()

  return (
    <div className="bg-white/[0.07] backdrop-blur-xl border border-white/15 rounded-2xl p-4 shadow-xl flex-1">
      <h3 className="text-center font-extrabold text-amber-300 mb-3 text-sm flex items-center justify-center gap-2">
        📦 Kepingan Puzzle — Jawab Soal untuk Memasang!
      </h3>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
        {PUZZLE_PIECES.map((piece, idx) => {
          const answered = answeredPieces.has(piece.id)
          const isActive = activePieceId === piece.id
          const isCurrent = currentPieceId === piece.id && !answered

          return (
            <button
              key={piece.id}
              onClick={() => !answered && onSelectPiece(piece.id)}
              disabled={answered}
              className={cn(
                "relative rounded-2xl p-3 text-left transition-all duration-200 border-2 select-none",
                "bg-gradient-to-br from-violet-900/40 to-sky-900/30",
                answered
                  ? "opacity-35 cursor-default border-white/10"
                  : "cursor-pointer hover:-translate-y-1 hover:scale-[1.03] hover:shadow-xl",
                isActive && !answered && "border-amber-400 shadow-[0_0_0_3px_rgba(251,191,36,0.35)] scale-[1.04]",
                isCurrent && !answered && !isActive
                  ? "border-emerald-400 animate-card-glow"
                  : !isActive && !answered ? "border-violet-500/30" : "",
              )}
              style={{ animationDelay: `${idx * 0.04}s` }}
            >
              {/* Answered badge */}
              {answered && (
                <span className="absolute top-1.5 right-1.5 text-sm z-10">✅</span>
              )}
              {/* Current badge */}
              {isCurrent && (
                <span className="absolute top-1 right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 animate-blink-dot shadow-[0_0_6px_rgba(74,222,128,0.8)]" />
              )}

              <div className="flex items-center gap-1.5 mb-1.5">
                <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-gradient-to-br from-violet-500 to-sky-400 text-white text-[0.65rem] font-black shrink-0">
                  {piece.id}
                </span>
                <span className="text-lg leading-none">{piece.emoji}</span>
              </div>
              <p className="text-[0.7rem] text-white/60 font-semibold leading-tight line-clamp-3">
                {piece.question}
              </p>
            </button>
          )
        })}
      </div>
    </div>
  )
}
