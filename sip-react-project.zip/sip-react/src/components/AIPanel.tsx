import { useApp } from '@/context/AppContext'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

export default function AIPanel() {
  const { aiMessage, isSpeaking, isListening, micAllowed, repeatLastAI, startListening, stopListening } = useApp()

  const handleGlobalListen = () => {
    if (isListening) { stopListening(); return }
    startListening((_t) => {
      // Voice input handled contextually by game
    }, 'Katakan jawaban atau perintah...')
  }

  return (
    <div className="bg-white/[0.07] backdrop-blur-xl border border-white/15 rounded-2xl p-4 mb-4 flex items-center gap-4 shadow-xl">
      {/* Avatar */}
      <div className={cn(
        "relative w-14 h-14 min-w-[56px] rounded-full flex items-center justify-center text-2xl shadow-xl",
        "bg-gradient-to-br from-violet-500 to-sky-400",
        isSpeaking && "ring-2 ring-violet-400 ring-offset-2 ring-offset-transparent"
      )}>
        🤖
        {isSpeaking && (
          <span className="absolute inset-[-6px] rounded-full border-2 border-violet-400 animate-ripple pointer-events-none" />
        )}
      </div>

      {/* Message */}
      <div className="flex-1 min-w-0">
        <div className="text-[0.65rem] font-black uppercase tracking-widest text-violet-400 mb-1">
          🌟 SIP AI Assistant
        </div>
        <p className="text-white/90 font-semibold leading-snug text-sm md:text-base line-clamp-3">
          {aiMessage}
          {isSpeaking && (
            <span className="inline-flex items-end gap-[3px] ml-2 h-4">
              {[0, 0.1, 0.2, 0.3].map((d, i) => (
                <span
                  key={i}
                  className="inline-block w-[3px] bg-violet-400 rounded-sm"
                  style={{ animation: `wave 0.8s ease-in-out ${d}s infinite`, minHeight: '4px' }}
                />
              ))}
            </span>
          )}
        </p>
      </div>

      {/* Buttons */}
      <div className="flex flex-col gap-2 shrink-0">
        {micAllowed && (
          <Button
            size="sm"
            variant={isListening ? 'listening' : 'green'}
            onClick={handleGlobalListen}
            className="text-xs px-3"
          >
            {isListening ? '🔴 Stop' : '🎤 Jawab'}
          </Button>
        )}
        <Button size="sm" variant="ghost" onClick={repeatLastAI} className="text-xs px-3 border border-sky-500/30 text-sky-300">
          🔊 Ulangi
        </Button>
      </div>
    </div>
  )
}
