# 🧩 Smart Inclusive Puzzle (SIP)

Website puzzle digital interaktif dengan AI suara untuk pembelajaran matematika SD.

## Fitur
- 🤖 AI dengan Text-to-Speech (bahasa Indonesia)
- 🎙️ Deteksi suara untuk menjawab soal
- 🧩 16 kepingan puzzle dengan soal matematika SD
- 📋 6 soal bonus setelah puzzle selesai
- 📱 Responsif untuk HP, Tablet, Laptop
- 🎨 Desain modern dengan gradient warna segar

## Deploy ke Vercel via GitHub

1. Upload folder ini ke GitHub repository
2. Buka [vercel.com](https://vercel.com)
3. Klik **"New Project"** → Import dari GitHub
4. Pilih repository ini → Klik **Deploy**
5. Selesai! Website live otomatis 🎉

## Cara Penggunaan
1. Buka website → AI menyapa secara otomatis
2. Klik **Mulai Bermain** → Izinkan mikrofon
3. AI membacakan soal secara acak
4. Jawab dengan **suara** atau **ketikan angka**
5. Kepingan puzzle terpasang jika jawaban benar
6. Jawab 6 soal bonus setelah semua kepingan terpasang
