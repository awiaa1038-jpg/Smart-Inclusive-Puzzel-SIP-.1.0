import type { PuzzlePiece, FinalQuestion } from '@/types'

export const PUZZLE_PIECES: PuzzlePiece[] = [
  { id: 1,  emoji: "🍎", question: "Budi punya 7 apel, lalu dapat 5 lagi. Berapa total apel Budi?",              answer: 12, hint: "7 + 5 = ?" },
  { id: 2,  emoji: "🐔", question: "Ibu punya 20 telur, dipakai 8 untuk memasak. Sisa telur ibu?",               answer: 12, hint: "20 − 8 = ?" },
  { id: 3,  emoji: "🎒", question: "Ada 4 kotak pensil, tiap kotak isi 6. Berapa total pensil?",                  answer: 24, hint: "4 × 6 = ?" },
  { id: 4,  emoji: "🍕", question: "Pizza dipotong 8 bagian, dimakan 3 bagian. Sisa berapa?",                     answer: 5,  hint: "8 − 3 = ?" },
  { id: 5,  emoji: "🌸", question: "Satu bunga punya 5 kelopak. 9 bunga punya berapa kelopak?",                   answer: 45, hint: "9 × 5 = ?" },
  { id: 6,  emoji: "🚌", question: "Bus ada 6 baris, tiap baris 4 kursi. Total kursi berapa?",                    answer: 24, hint: "6 × 4 = ?" },
  { id: 7,  emoji: "⚽", question: "Dino punya 15 bola. Berikan 6 ke teman. Sisa bola Dino?",                    answer: 9,  hint: "15 − 6 = ?" },
  { id: 8,  emoji: "🍬", question: "30 permen dibagi 5 anak sama rata. Tiap anak dapat berapa?",                  answer: 6,  hint: "30 ÷ 5 = ?" },
  { id: 9,  emoji: "📚", question: "Rak buku ada 7, tiap rak 8 buku. Total buku?",                               answer: 56, hint: "7 × 8 = ?" },
  { id: 10, emoji: "🐟", question: "Aquarium punya 40 ikan. 13 dipindah. Sisa ikan?",                            answer: 27, hint: "40 − 13 = ?" },
  { id: 11, emoji: "🎈", question: "Ulang tahun ada 48 balon, dibagi 6 meja. Tiap meja dapat berapa?",            answer: 8,  hint: "48 ÷ 6 = ?" },
  { id: 12, emoji: "🌈", question: "Kelas A: 18 siswa, Kelas B: 15 siswa. Total berapa?",                        answer: 33, hint: "18 + 15 = ?" },
  { id: 13, emoji: "🏆", question: "Lomba diikuti 9 tim, tiap tim 4 anggota. Total peserta?",                     answer: 36, hint: "9 × 4 = ?" },
  { id: 14, emoji: "🦋", question: "Taman ada 63 bunga, diambil 25. Sisa bunga?",                                answer: 38, hint: "63 − 25 = ?" },
  { id: 15, emoji: "🎵", question: "Lagu berdurasi 3 menit. 7 lagu habis berapa menit?",                          answer: 21, hint: "3 × 7 = ?" },
  { id: 16, emoji: "💡", question: "Ada 72 lampu dibagi ke 8 ruangan sama banyak. Tiap ruangan berapa?",          answer: 9,  hint: "72 ÷ 8 = ?" },
]

export const FINAL_QUESTIONS: FinalQuestion[] = [
  { id: 1, question: "Di sebuah kelas terdapat 12 siswa laki-laki dan 8 siswa perempuan. Berapa jumlah seluruh siswa di kelas tersebut?", answer: 20 },
  { id: 2, question: "Rina memiliki 25 permen. Ia membagikan 9 permen kepada temannya. Berapa sisa permen Rina sekarang?", answer: 16 },
  { id: 3, question: "Sebuah perpustakaan memiliki 6 rak buku. Setiap rak berisi 15 buku. Berapa jumlah seluruh buku di perpustakaan tersebut?", answer: 90 },
  { id: 4, question: "Ayah membeli 4 kantong jeruk. Setiap kantong berisi 12 jeruk. Berapa jumlah seluruh jeruk yang dibeli ayah?", answer: 48 },
  { id: 5, question: "Sebuah sekolah memiliki 240 siswa. Jika setiap kelas berisi 30 siswa, berapa jumlah kelas yang ada di sekolah tersebut?", answer: 8 },
  { id: 6, question: "Doni memiliki 50 ribu rupiah. Ia membeli buku seharga 18 ribu rupiah dan pensil seharga 7 ribu rupiah. Berapa sisa uang Doni sekarang?", answer: 25 },
]

export function shuffleArray<T>(arr: T[]): T[] {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

export function parseSpokenNumber(text: string): number | null {
  const lower = text.toLowerCase().trim()
  const wordMap: Record<string, number> = {
    'nol': 0, 'zero': 0,
    'satu': 1, 'one': 1,
    'dua': 2, 'two': 2,
    'tiga': 3, 'three': 3,
    'empat': 4, 'four': 4,
    'lima': 5, 'five': 5,
    'enam': 6, 'six': 6,
    'tujuh': 7, 'seven': 7,
    'delapan': 8, 'eight': 8,
    'sembilan': 9, 'nine': 9,
    'sepuluh': 10, 'ten': 10,
    'sebelas': 11, 'eleven': 11,
    'dua belas': 12, 'twelve': 12,
    'dua puluh': 20, 'twenty': 20,
    'dua puluh satu': 21,
    'dua puluh lima': 25,
    'dua puluh tujuh': 27,
    'tiga puluh': 30, 'thirty': 30,
    'tiga puluh tiga': 33,
    'tiga puluh delapan': 38,
    'tiga puluh enam': 36,
    'empat puluh': 40, 'forty': 40,
    'empat puluh delapan': 48,
    'empat puluh lima': 45,
    'empat puluh delapan': 48,
    'lima puluh': 50, 'fifty': 50,
    'lima puluh enam': 56,
    'enam puluh': 60, 'sixty': 60,
    'tujuh puluh dua': 72,
    'delapan puluh': 80, 'eighty': 80,
    'sembilan puluh': 90, 'ninety': 90,
    'seratus': 100, 'one hundred': 100,
  }
  for (const [k, v] of Object.entries(wordMap)) {
    if (lower.includes(k)) return v
  }
  const match = lower.match(/\d+/)
  if (match) return parseInt(match[0])
  return null
}
