import { useApp } from '@/context/AppContext'
import { Button } from '@/components/ui/button'

export default function ListenOverlay() {
  const { isListening, listenTranscript, stopListening } = useApp()

  if (!isListening) return null

  return (
    <div className="fixed inset-0 z-[800] flex items-center justify-center bg-black/70 backdrop-blur-md px-5">
      <div className="w-full max-w-sm bg-gradient-to-br from-[#1a0533] to-[#0b1e3d] border-2 border-emerald-400/50 rounded-3xl p-8 text-center shadow-[0_0_40px_rgba(74,222,128,0.25)] animate-bounce-in">
        <div className="text-5xl mb-2 animate-mic-bounce">🎤</div>
        <h3 className="text-2xl font-extrabold text-emerald-400 mb-1">Mendengarkan...</h3>
        <p className="text-white/50 text-sm mb-4">Sebutkan jawaban kamu dengan jelas</p>

        {/* Waves */}
        <div className="flex items-end justify-center gap-[5px] h-10 mb-4">
          {[0, 0.1, 0.2, 0.3, 0.15].map((d, i) => (
            <span
              key={i}
              className="block w-[6px] bg-gradient-to-t from-emerald-400 to-sky-400 rounded-full"
              style={{
                animation: `wave 0.7s ease-in-out ${d}s infinite`,
                minHeight: '4px',
              }}
            />
          ))}
        </div>

        <div className="bg-emerald-400/10 border border-emerald-400/25 rounded-xl px-4 py-3 min-h-[44px] text-emerald-300 font-bold text-base mb-5">
          {listenTranscript || 'Menunggu suara...'}
        </div>

        <Button variant="destructive" size="sm" onClick={stopListening} className="w-full">
          ❌ Batal
        </Button>
      </div>
    </div>
  )
}
